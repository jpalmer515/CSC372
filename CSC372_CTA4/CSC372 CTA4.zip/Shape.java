

abstract class Shape {
    
    //Abstract method "surface_area()", return double
    abstract double surface_area();

    //Abstract method "volume()", return double
    abstract double volume();
    
}
